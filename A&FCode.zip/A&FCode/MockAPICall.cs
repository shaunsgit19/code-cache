﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using AFWebApplication1.Models;

namespace AFWebApplication1.Repository
{
    //Assumption: The MockAPI is actually a RESTful service returning an array of JSON objects of employee data.
    //Happy path using the NewtonSoft.Json library.
    public static class MockAPICall
    {
        private const string apiUri = "http://5d7a59779edf7400140aa043.mockapi.io/cline";

        public static List<EmployeeInfo> CallMockAPINewtonSoftJson()
        {
            var jsonData = GetJsonResponse();
            var data = JsonConvert.DeserializeObject<List<EmployeeInfo>>(jsonData);

            return data;
        }

        //Call RESTful API and retrieve response. 
        private static string GetJsonResponse()
        {
            string jsonResponse = string.Empty;

            using (var httpClient = new HttpClient())
            {
                jsonResponse = httpClient.GetStringAsync(new Uri(apiUri)).Result;
            }

            return jsonResponse;
        }
    }
}