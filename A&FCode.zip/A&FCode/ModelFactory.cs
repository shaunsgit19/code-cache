﻿using AFWebApplication1.Controllers;
using AFWebApplication1.Models;
using AFWebApplication1.Repository;

namespace AFWebApplication1.Factories
{
    public static class ModelFactory
    {
        public static Employee GetEmployeeModel(this HomeController con)
        {
            var model = new Employee();
            model.EmployeeInfo = MockAPICall.CallMockAPINewtonSoftJson();

            return model;
        }
    }
}